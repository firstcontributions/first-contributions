<body><article class="markdown-body"><p><a href="https://github.com/ellerbrock/open-source-badges/"><img src="https://camo.githubusercontent.com/d41b9884bd102b525c8fb9a8c3c8d3bbed2b67f0/68747470733a2f2f6261646765732e66726170736f66742e636f6d2f6f732f76312f6f70656e2d736f757263652e7376673f763d313033" alt="Open Source Love" data-canonical-src="https://badges.frapsoft.com/os/v1/open-source.svg?v=103" style="max-width:100%;"></a>
<a href="https://join.slack.com/t/firstcontributors/shared_invite/enQtNjkxNzQwNzA2MTMwLTVhMWJjNjg2ODRlNWZhNjIzYjgwNDIyZWYwZjhjYTQ4OTBjMWM0MmFhZDUxNzBiYzczMGNiYzcxNjkzZDZlMDM" rel="nofollow"><img align="right" width="150" src="../assets/join-slack-team.png" data-canonical-src="https://firstcontributions.herokuapp.com/badge.svg" style="max-width:100%;"></a>
<a href="https://opensource.org/licenses/MIT" rel="nofollow"><img src="https://camo.githubusercontent.com/76f0e887c183ccc31c1cb63c33d2dbf48cb2df51/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4c6963656e73652d4d49542d677265656e2e737667" alt="License: MIT" data-canonical-src="https://img.shields.io/badge/License-MIT-green.svg" style="max-width:100%;"></a>
<a href="https://www.codetriage.com/roshanjossey/first-contributions" rel="nofollow"><img src="https://camo.githubusercontent.com/8e53aecabdd0316ce198fe932798bb0f8754b30f/68747470733a2f2f7777772e636f64657472696167652e636f6d2f726f7368616e6a6f737365792f66697273742d636f6e747269627574696f6e732f6261646765732f75736572732e737667" alt="Open Source Helpers"></a></p>
<p dir="rtl">بخاطر ترجمه ضعیف شرمندم میتونین نسخه فینگلیش رو بخونین که قطعا بهتره</p>
<h1 dir="rtl">
<a id="user-content-اولین-مشارکت" class="anchor" href="#%D8%A7%D9%88%D9%84%DB%8C%D9%86-%D9%85%D8%B4%D8%A7%D8%B1%DA%A9%D8%AA" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a>اولین مشارکت</h1>
<p dir="rtl">سخته . همیشه سخته که برای اولین بار کاری رو انجام بدی. مخصوصا وقتی داری همکاری میکنی. اشتباه کردن چیز راحتی نیست. اما دنیای متن باز تماماً درباره مشارکت و همکاری هست. ما میخواستیم تا راه رو ساده کنیم تا مشارکت کننده های جدید این همکاری رو برای بار اول یاد بگیرن</p>
<p dir="rtl">خوندن مقالات و نگاه کردن ویدیو های آموزشی میتونه کمک کنه. اما چی از واقعاً انجام دادن کار بدون خرابکاری بهتره ؟ هدف این پروژه فراهم کردن یک راهنما و ساده کردن مسیر برای تازه کار هاست تا اولین مشارکت رو انجام بدن. یادت باشه: هرچی ریلکس تر باشی. بهتر یاد میگیری. اگه میخوای اولین همکاریت رو انجام بدی فقط راهنمای قدم به قدم ساده زیر رو انجام بده. ما قول میدیم. خوش میگذره </p>

<p dir="rtl">اگه روی دستگاهت گیت نداری.
<a href="https://help.github.com/articles/set-up-git/"> نصبش کن</a>.</p>
<h2 dir="rtl">
<a id="user-content-این-ریپوزیتوری-رو-فورک-کن" class="anchor" href="#%D8%A7%DB%8C%D9%86-%D8%B1%DB%8C%D9%BE%D9%88%D8%B2%DB%8C%D8%AA%D9%88%D8%B1%DB%8C-%D8%B1%D9%88-%D9%81%D9%88%D8%B1%DA%A9-%DA%A9%D9%86" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a>این ریپوزیتوری رو فورک کن</h2>
<p dir="rtl">این ریپوزیتوری رو از طریق کلیک کردن روی دکمه فورک بالای این صفحه فورک کن
این کار یک کپی از ریپوزیتوری تو اکانتت میسازه</p>
<img style="float: left;" width="300" src="../assets/fork.png" alt="fork this repository" />
<h2 dir="rtl">
<a id="user-content-ریپپوزیتوری-رو-کلون-کن" class="anchor" href="#%D8%B1%DB%8C%D9%BE%D9%BE%D9%88%D8%B2%DB%8C%D8%AA%D9%88%D8%B1%DB%8C-%D8%B1%D9%88-%DA%A9%D9%84%D9%88%D9%86-%DA%A9%D9%86" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a>ریپپوزیتوری رو کلون کن</h2>
<p dir="rtl">حالا ریپ و رو داخل کامپیوترت کلون کن. روی دکمه کلون کلیک کن و بعد روی (کپی در کلیپبورد) کلیک کن</p>
<img style="float: left;" width="300" src="../assets/clone.png" alt="clone this repository" />
<img style="float: left;" width="300" src="../assets/copy-to-clipboard.png" alt="copy URL to clipboard" />
<p dir="rtl">ترمینال رو باز کن و دستورات زیر رو وارد کن</p>
<pre><code>git clone "لینکی که کپی کردی"
</code></pre>
<p dir="rtl">جایی که (لینکی که کپی کردی) هست درواقع آدرس ریپوزیتوری هست که تو قدم پیش دیدی</p>

<p dir="rtl">برای مثال</p>
<pre><code>git clone https://github.com/this-is-you/first-contributions.git
</code></pre>
<p dir="rtl">داخل لینک بجای
<code>this-is-you</code>
نام کاربری گیتهاب خودت رو قرار بده
تو این مرحله داری محتویات ریپوزیتوری رو از گیتهاب کپی میکنی تو کامپیوتر خودت</p>
<h2 dir="rtl">
<a id="user-content-برنچ-شاخه-بساز" class="anchor" href="#%D8%A8%D8%B1%D9%86%DA%86-%D8%B4%D8%A7%D8%AE%D9%87-%D8%A8%D8%B3%D8%A7%D8%B2" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a>برنچ (شاخه) بساز</h2>
<p dir="rtl">اگه هنوز داخل پوشه ریپوزیتوری نیستی. برو داخلش</p>
<pre><code>cd first-contributions
</code></pre>
<p dir="rtl">حالا با استفاده از دستور
<code>git checkout</code>
یک برنچ جدید بساز</p>
<pre><code>git checkout -b &lt;add-your-name&gt;
</code></pre>
<p dir="rtl">برای مثال</p>
<pre><code>git checkout -b add-alonzo-church
</code></pre>
<p dir="rtl">لازم نیست کلمه
<code>add</code>
رو اول اسم برنچ بنویسی اما از اونجا که هدف از ساخت این برنچ اضافه کردن اسمت به لیست هست کار منطقی ای هست</p>
<h2 dir="rtl">
<a id="user-content-تغیرات-ضروری-رو-انجام-بده-و-کامیت-کن" class="anchor" href="#%D8%AA%D8%BA%DB%8C%D8%B1%D8%A7%D8%AA-%D8%B6%D8%B1%D9%88%D8%B1%DB%8C-%D8%B1%D9%88-%D8%A7%D9%86%D8%AC%D8%A7%D9%85-%D8%A8%D8%AF%D9%87-%D9%88-%DA%A9%D8%A7%D9%85%DB%8C%D8%AA-%DA%A9%D9%86" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a>تغیرات ضروری رو انجام بده و کامیت کن</h2>
<p dir="rtl">حالا فایل
<code>Contributors.md</code>
رو داخل تکست ایدتور باز کن و اسمت رو به آخر فایل اضافه ک. بعد فابل رو ذخیره کن. اگه حالا وارد پوشه پروژه بشی و دستور
<code>git status</code>
رو اجرا کنی. میبینی که تغیرات اونجاست. حالا اون تغیرات رو به برنچی که ساختی اضافه کن با استفاده از دستور
<code>git add</code></p>
<pre><code>git add Contributors.md
</code></pre>
<p dir="rtl">حالا اون تغیرات با استفاده از دستور زیر کامیت کن
<code>git commit</code></p>
<pre><code>git commit -m "Add &lt;your-name&gt; to Contributors list"
</code></pre>
<p dir="rtl">جای
<code>&lt;your-name&gt;</code>
رو با اسم خودت عوض کن</p>
<h2 dir="rtl">
<a id="user-content-تغیرات-رو-به-گیتهاب-پوش-کن" class="anchor" href="#%D8%AA%D8%BA%DB%8C%D8%B1%D8%A7%D8%AA-%D8%B1%D9%88-%D8%A8%D9%87-%DA%AF%DB%8C%D8%AA%D9%87%D8%A7%D8%A8-%D9%BE%D9%88%D8%B4-%DA%A9%D9%86" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a>تغیرات رو به گیتهاب پوش کن</h2>
<p dir="rtl">با استفاده از دستور زیر تغیراتت رو به گیتهاب پوش کن
<code>git push</code></p>
<pre><code>git push origin &lt;add-your-name&gt;
</code></pre>
<p dir="rtl">اسم
<code>&lt;add-your-name&gt;</code>
رو با اسم برنچی که ساخته بودی عوض کن</p>
<h2 dir="rtl">
<a id="user-content-تغیراتت-رو-برای-برسی-ثبت-کن" class="anchor" href="#%D8%AA%D8%BA%DB%8C%D8%B1%D8%A7%D8%AA%D8%AA-%D8%B1%D9%88-%D8%A8%D8%B1%D8%A7%DB%8C-%D8%A8%D8%B1%D8%B3%DB%8C-%D8%AB%D8%A8%D8%AA-%DA%A9%D9%86" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a>تغیراتت رو برای برسی ثبت کن</h2>
<p dir="rtl">اگه بری داخل ریپوزیتوریت تو گیتهاب. میبینی که دکمه
<code>Compare &amp; pull request</code>
وجود داره . روش کلیک کن</p>
<img style="float: left;" src="../assets/compare-and-pull.png" alt="create a pull request" />
<p dir="rtl">حالا دستور پل رو ثبت کن</p>
<img style="float: left;" src="../assets/submit-pull-request.png" alt="submit pull request" />
<p dir="rtl">بزودی من تمام تغیرات تو رو به شاخه اصلی این پروژه اضافه میکنم
زمانی که تغیرات ثبت شد یک ایمیل دریافت میکنی</p>
<h2 dir="rtl">
<a id="user-content-از-اینجا-کجا-برم-" class="anchor" href="#%D8%A7%D8%B2-%D8%A7%DB%8C%D9%86%D8%AC%D8%A7-%DA%A9%D8%AC%D8%A7-%D8%A8%D8%B1%D9%85-" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a>از اینجا کجا برم ؟</h2>
<p dir="rtl">مشارکتت جشن بگیر و با دوستات و دنبال کننده هات به اشتراک بزار
<a href="https://roshanjossey.github.io/first-contributions/#social-share" rel="nofollow">web app</a>.</p>
<p dir="rtl">در صورتی که سوالی داشتی یا کمک خواستی میتونی به گروه اسلک ما ملحق بشی
<a href="https://join.slack.com/t/firstcontributors/shared_invite/enQtMzE1MTYwNzI3ODQ0LTZiMDA2OGI2NTYyNjM1MTFiNTc4YTRhZTg4OWZjMzA0ZWZmY2UxYzVkMzI1ZmVmOWI4ODdkZWQwNTM2NDVmNjY" rel="nofollow">Join slack team</a>.</p>
<p dir="rtl">Now let's get you started with contributing to other projects. We've compiled a list of projects with easy issues you can get started on. Check out <a href="https://roshanjossey.github.io/first-contributions/#project-list" rel="nofollow">the list of projects in web app</a>.</p>
<h3 dir="rtl">
<a id="user-content-additional-material" class="anchor" href="#additional-material" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a><a href="../additional-material/git_workflow_scenarios/additional-material.md">Additional material</a>
</h3>
<h2 dir="rtl">
<a id="user-content-tutorials-using-other-tools" class="anchor" href="#tutorials-using-other-tools" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a>Tutorials Using Other Tools</h2>
<table>
<thead>
<tr>
<th><a href="../github-desktop-tutorial.md"><img alt="GitHub Desktop" src="https://camo.githubusercontent.com/59366250bb159bb039b8eba5bd19c615dfc1819a/68747470733a2f2f6465736b746f702e6769746875622e636f6d2f696d616765732f6465736b746f702d69636f6e2e737667" width="100" data-canonical-src="https://desktop.github.com/images/desktop-icon.svg" style="max-width:100%;"></a></th>
<th><a href="../github-windows-vs2017-tutorial.md"><img alt="Visual Studio 2017" src="https://upload.wikimedia.org/wikipedia/commons/c/cd/Visual_Studio_2017_Logo.svg" width="100" data-canonical-src="https://upload.wikimedia.org/wikipedia/commons/c/cd/Visual_Studio_2017_Logo.svg" style="max-width:100%;"></a></th>
<th><a href="../gitkraken-tutorial.md"><img alt="GitKraken" src="../assets/gk-icon.png" width="100" style="max-width:100%;"></a></th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="../github-desktop-tutorial.md">GitHub Desktop</a></td>
<td><a href="../github-windows-vs2017-tutorial.md">Visual Studio 2017</a></td>
<td><a href="../gitkraken-tutorial.md">GitKraken</a></td>
</tr>
</tbody>
</table>
<h2>
<a id="user-content-self-promotion" class="anchor" href="#self-promotion" aria-hidden="true"><span aria-hidden="true" class="octicon octicon-link"></span></a>Self-Promotion</h2>
<p>If you liked this project, star it on <a href="https://github.com/Roshanjossey/first-contributions">GitHub</a>.
If you're feeling especially charitable, follow <a href="https://roshanjossey.github.io/" rel="nofollow">Roshan</a> on
<a href="https://twitter.com/sudo__bangbang" rel="nofollow">Twitter</a> and
<a href="https://github.com/roshanjossey">GitHub</a>.</p>
<p><a href="http://saasgrids.com" rel="nofollow"> <img alt="http://saasgrids.com" src="../assets/saasgrids-banner.png" width="500" style="max-width:100%;"></a></p>
</article></body></html>

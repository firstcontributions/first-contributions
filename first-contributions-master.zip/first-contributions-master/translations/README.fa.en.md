[![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges/)
[<img align="right" width="150" src="../assets/join-slack-team.png">](https://join.slack.com/t/firstcontributors/shared_invite/enQtNjkxNzQwNzA2MTMwLTVhMWJjNjg2ODRlNWZhNjIzYjgwNDIyZWYwZjhjYTQ4OTBjMWM0MmFhZDUxNzBiYzczMGNiYzcxNjkzZDZlMDM)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Open Source Helpers](https://www.codetriage.com/roshanjossey/first-contributions/badges/users.svg)](https://www.codetriage.com/roshanjossey/first-contributions)

Tavajjoh : IN Noskheye Finglish Az Tarjomeye Farsie Hamin Matne Va Kheyli Az Vazhe Ha Be Shekle Englishe Khodeshoon Neveshte Shodan Chon Tarjomashoon Chize Jalebi Az Aab Dar Nemiad
# Avvalin Contribution (Hamkari, Mosharekat)

Sakhte. Hamishe Anjam Dadane Kari Baraye Avvalin Bar Sakhte. Makhsoosan Vaghti Dari Mosharekat Mikoni, Eshtebah Kardan Kare Rahati Nist. Amma Open-Source Tamaman Darbareye Mosharekat Va Ham Karie. Ma Mikhastim Rah Ro Sade Konim Ta Contributer Haye Jadide Open-Source Betoonan Baraye Avvalin Bar Yad Begiran Va Mosharekat Konan

Khoondane Maghale Va Didane Tutorial Ha Mitoone Komak Kone, Amma Chi Az Vaghan Anjam Dadane Kar Ha Bedoone Kharab Kari Behtare ?
Hadafe IN Proje Mohayya Kardane Yek Rahnama Va Sade Kardane Rahe Taze Kar Ha Baraye Avvalin Mosharekat.eshoone . Yadetoon Bashe: Harchi Relax Tar Bashi, Behtar Yad Migiri. Age Donbale IN Hasti Ke Avvalin Contribute Ro Anjam Bedi, Faghat Ghadam Be Ghadam Rahnamaye Zir Ro Donbal Kon. Ma Behet Ghol Midim, Gharare Khosh Begzare :D

#### *IN Ro Dar [Zaban Haye Dige](../Translations.md) Bekhoonin.*

<img align="right" width="300" src="../assets/fork.png" alt="fork this repository" />

Age Rooye Computeret GIT Nadari,Nasbesh Kon
[Install It]( https://help.github.com/articles/set-up-git/).

## IN Repository Ro Fork Kon

IN Repo Ro Ba Click Kardan Rooye Dokmeye Fork Az Balaye Safhe Fork Kon.
IN Ye Copy Az Repository Miare Too Accountet

## Repository Ro Clone Kon

<img align="right" width="300" src="../assets/clone.png" alt="clone this repository" />
Hala Repo Ro Roo Computeret Clone Kon. Click Kon Roo Dokmeye Clome Va Bad Click Kon Rooye Icone *copy to clipboard*

Terminal Ro Baz Kon Va Dastoorate Zir Ro Vared Kon:

```
git clone "url you just copied"
```
Jayi Ke "URL You Just Copied" ( Bedoone Alamate " Vojood Dare ) URL IN Repository Ke Too Marhaleye Ghabli Didi Vojood Dare

<img align="right" width="300" src="../assets/copy-to-clipboard.png" alt="copy URL to clipboard" />

Baraye Mesal:
```
git clone https://github.com/this-is-you/first-contributions.git
```
Jayi Ke `this-is-you` Hast Bayad Username Githube Ro Benevisi. Too IN Marhale Dari Mohtaviate Repositorye `first-contributions` Ro Copy Mikoni Too Computeret

## Sakhtane Branch ( Shakhe )
Too Cpmputeret Boro Directorye Repository ( Albate Age Hanooz Dakhelesh Nisti )

```
cd first-contributions
```
Hala Ba Estefade Az Dastoore `git checkout` Ye Branch Besaz:
```
git checkout -b <add-your-name>
```

Baraye Mesal:
```
git checkout -b add-alonzo-church
```
( Lazem Nist Avvale Esme Branch Vazheye "add" Ro Benevisi. Amma Az OON Ja Ke Dari Esmet Ro Be List Ezafe Mikoni Kare Manteghi-e Hast)

## Taghirate Zaroori Ro Anjam Bede Va Bad Commit Kon

Hala File `Contributors.md` Ro Too Text Editor Baz Kon, Esmet Ro Ezafe Kon, Va Bad Save Kon. Age Beri Dakhele Directorye Proje Va Dastoore `git status` Ro Bezani, Taghirat Ro Mibini. Va OON Taghirati Ke Dakhele Branchi Ke Sakhti Ro Ba Dastoore `git add` Ezafe Kon

```
git add Contributors.md
```

Hala Taghirat Ro Ba Dastoore `git commit` Commit Kon :
```
git commit -m "Add <your-name> to Contributors list"
```
Be Jaye `<your-name>` Esme Khodet Ro Benevis.

## Taghirat Ro Be GitHub Push Kon .

Ba Dastoore `git push` Taghiratet Ro Push Kon:
```
git push origin <add-your-name>
```
Be Jaye `<add-your-name>` Esme Branchi Ke Sakhte Boodi Ro Benevis.

## Taghiratet Ro Baraye Barresi Submit Kon

Age Beri Too Repository Roo GitHub, Dokmeye `Compare & pull request` Ro Mibini. Roosh Click Kon

<img style="float: right;" src="../assets/compare-and-pull.png" alt="create a pull request" />

Hala Darkhate Pull Ro Submit Kon

<img style="float: right;" src="../assets/submit-pull-request.png" alt="submit pull request" />

Be Zoodi Man Tamame Taghiratet Ro Be Branche "Master" Ezafe Mikonam. Be Mahze IN Ke Taghirat Submit Shod Email Daryaft Mikoni

## Az IN Ja Koja Beram ?

Mosharekatet Ro Jashn Begir Va Ba Follower Ha o Doostat Be Eshterak Bezar
 [web app](https://roshanjossey.github.io/first-contributions/#social-share).

Dar Soorati Ke Soal Dashti Ya Komak Khasti Mitooni Be Teame Slacke Ma Bepeyvandi
[Join slack team](https://join.slack.com/t/firstcontributors/shared_invite/enQtMzE1MTYwNzI3ODQ0LTZiMDA2OGI2NTYyNjM1MTFiNTc4YTRhZTg4OWZjMzA0ZWZmY2UxYzVkMzI1ZmVmOWI4ODdkZWQwNTM2NDVmNjY).

Hala Bia Too Proje Haye Dige Mosharekat Konim. We Ye Listi Az Proje Hayi Ba Moshkelate Sade Gerd Avari Kardim Ke Mitooni Az OON Ja Shoroo Koni.
[the list of projects in web app](https://roshanjossey.github.io/first-contributions/#project-list).

### [Additional material](../additional-material/git_workflow_scenarios/additional-material.md)


## Tutorials Using Other Tools

|<a href="../github-desktop-tutorial.md"><img alt="GitHub Desktop" src="https://desktop.github.com/images/desktop-icon.svg" width="100"></a>|<a href="../github-windows-vs2017-tutorial.md"><img alt="Visual Studio 2017" src="https://upload.wikimedia.org/wikipedia/commons/c/cd/Visual_Studio_2017_Logo.svg" width="100"></a>|<a href="../gitkraken-tutorial.md"><img alt="GitKraken" src="/assets/gk-icon.png" width="100"></a>|
|---|---|---|
|[GitHub Desktop](../github-desktop-tutorial.md)|[Visual Studio 2017](../github-windows-vs2017-tutorial.md)|[GitKraken](../gitkraken-tutorial.md)|

